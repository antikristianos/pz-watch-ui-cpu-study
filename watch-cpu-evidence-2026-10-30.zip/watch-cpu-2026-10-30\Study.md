# Watch UI CPU full-day study — 2026-10-30

Completed 52 scenarios and 260 measurements. Each repetition replays 5,400 virtual seconds: a full 90-minute day at 30/120 scheduled UI calls per second. Five repeats use fresh Lua environments within one JVM per scenario. All output signatures agree, all used source-input hashes remain unchanged, and no guarded Java exception occurred.

46/52 scenarios meet the stricter publication stability flag: at least five samples and population CV <= 5% for both measurement-thread CPU time and cycles. This descriptive flag is not a significance test. The measured scope is the display/update core including the test observer, not total mod/game CPU or FPS.

## Commissioning and execution

Antikristianos, developer of Hi-Res Clock, commissioned the study and specified its requested scope and reviewed presentation. GPT via Codex developed and ran the local benchmark tools, performed the numerical analysis and prepared the interpretation and draft. The commissioner did not modify the raw measurements or calculated results or specify a preferred ranking or predetermined outcome. CPU timings came from actual Java/Kahlua execution. This process attribution does not itself establish methodological independence; the documented method and records remain the basis for assessment.

## Retained evidence

- [Every scenario and observed spread](<All scenarios.md>)
- [Machine and exact command](machine-and-command.json)
- [Derived statistics](analysis.json), [raw samples](raw.csv), [native input hashes](inputs.json) and [case order](schedule.json)
- [Capture metadata](results.json), [log directory](logs) and [file hashes](evidence-sha256.json); any metadata recovery is identified below
- [Exported comparison chart](<Watch CPU comparison.png>)
- [Reader-facing horizontal percentage bars](<Watch CPU relative demand.png>): fixed Vanilla 30 UI FPS = 100% reference for both UI cadences, using total day CPU work
- [Release equivalence](release-equivalence.json) and [Workshop author references](guide.references.json)
- [Input-integrity audit](input-validation-audit.json)

The representative chart uses 1-minute modes where supported and native 10-minute Vanilla. It compares configured displays with different features; it does not rank code quality or establish feature-equivalent efficiency. The complete data retains every supported rate and Hi-Res slot count.

## Architecture and interpretation

The tested paths differ in texture, text, geometry, control and multi-watch output. Content updates, preparation, Lua/Java transitions and command submission can have different cadences. Reusing prepared data can change preparation work while submission remains. This benchmark times the combined executed path and observer; it does not isolate per-function costs, quantify avoidable work, establish feature-equivalent efficiency or assign code-quality ratings.

Clockwork moves Vanilla offscreen, retaining native calculations before clipping. Actual/WatchUI retain Vanilla as part of their composite display. Native inventory/provider scans and background callbacks are excluded for every mod, including Hi-Res. Their absent costs must not be silently added to, or inferred from, display-only ratios.

## Why earlier figures were retired

The initial harness verified deterministic output but missed Java failures caught by the installed Kahlua MethodCaller. An engine type in the premain agent signature caused Texture to load before transformer registration. Native Clock then stopped with null digit textures; its background had also not been initialized outside resize. Scaled AngelCodeFont glyphs additionally entered GenericSpriteRenderState directly, whose active queue state was absent. Earlier timings and the 520-sample qualification are invalid for performance comparisons.

The corrected harness checks Texture transformation and lookup, directly renders native Clock (38 digital commands), supplies the background and inert active UI state, verifies two scaled glyph commands, and latches the original Java exception from MethodCaller. A separate negative test confirms that the actual caller catching NumberFormatException sets this latch. The repaired short matrix passed all 52 scenarios/104 samples before the full-day run. The stopped pre-repair day attempt is not included here.

## Scope and statistical limits

CPU samples include the measurement thread only. GC/JIT worker CPU, GPU/driver work, the actual renderer queue, world simulation, native equipment scans and complete child traversal are outside the test. Allocated bytes describe allocation traffic, not retained memory. Native font/texture inputs are a fixed profile, not every possible user setting. The warm-up boundary starts all UI cadences at the same virtual instant.

The technical analysis ratios use medians against Vanilla at the same UI cadence. The reader-facing percentage bars instead use one fixed denominator: total day CPU work of Vanilla at 30 UI FPS = 100%, for both 30 and 120 selections. Observed min/max ratio envelopes are not confidence intervals. With one JVM per scenario, five within-process repetitions do not establish between-process, between-machine or every-configuration uncertainty. Close or noisy results must not be promoted into precise global rankings. Hardware timing variation remains possible despite identical inputs and processor affinity. No cycle count is converted into time.

A UI cost can consume CPU budget in a game session, but no achieved FPS loss follows from this benchmark alone. Absolute CPU time and work per scheduled second matter alongside relative factors. A dashboard and a small clock have different output; draw-command counts are neither GPU timings nor literal driver draw-call counts.

## Completion audit

All 260 measurements completed, but the original launcher stopped at its broad input-manifest guard before creating summary metadata. Exactly 60 files were removed from the unselected top-level LuaDigitalWatch duplicate during the run. Every remaining 3,094 manifest entry is byte-identical, there are no new matching inputs, and all 60 removed hashes match the unchanged selected 3676456221 package. The unchanged Lua loader resolves BENCH_ACTIVE only; texture lookup uses the selected root, Hi-Res/common and game, never that duplicate. Every raw record was matched against its original case log. Restore-WatchCpuCapture.ps1 reconstructs summary metadata without changing raw samples, logs, original hashes or source paths. The original broad guard remains recorded as failed (inputHashesUnchanged=false); the separate used-input audit passes. This is a documented recovery, not an original launcher PASS or a fresh measurement.

## API references

- [Oracle CPU-time monitoring](https://docs.oracle.com/en/java/javase/25/management/using-platform-mbean-server-and-platform-mxbeans.html)
- [Microsoft QueryThreadCycleTime](https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-querythreadcycletime)
- [Steam Guide BBCode](https://steamcommunity.com/comment/Guide/formattinghelp)
